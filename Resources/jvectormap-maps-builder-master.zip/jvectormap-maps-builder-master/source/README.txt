Put shapefiles in a sub-folder here, e.g. ne_50m_admin_0_countries/ne_50m_admin_0_countries.* (dbf, shp and shx). 
